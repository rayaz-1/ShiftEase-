ShiftEase – Daily Staff Planner

How to run the app:
1. Open a terminal or command prompt.
2. Navigate to the folder containing shift_planner.py.
3. Run the command: streamlit run shift_planner.py
4. The app will open in your web browser.

Make sure you have Python and the required packages installed.
Install packages using: pip install -r requirements.txt
